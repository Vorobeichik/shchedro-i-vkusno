import { useMemo, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

type MenuItem = {
  title: string;
  description: string;
  price: number;
  weight?: string;
  image?: string;
};

type MenuSection = {
  title: string;
  note: string;
  items: MenuItem[];
};

const heroImage =
  "https://images.pexels.com/photos/12645164/pexels-photo-12645164.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600";

const imageBank = {
  chicken:
    "https://images.pexels.com/photos/11826922/pexels-photo-11826922.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=650&w=940",
  soup: "https://images.pexels.com/photos/539451/pexels-photo-539451.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=650&w=940",
  salad:
    "https://images.pexels.com/photos/257816/pexels-photo-257816.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=650&w=940",
  rice: "https://images.pexels.com/photos/723198/pexels-photo-723198.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=650&w=940",
  bakery:
    "https://images.pexels.com/photos/7368044/pexels-photo-7368044.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  breakfast:
    "https://images.pexels.com/photos/6488857/pexels-photo-6488857.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
  lunch1: "/images/complex-lunch-1.jpg",
  lunch2: "/images/complex-lunch-2.jpg",
};

const menuSections: MenuSection[] = [
  {
    title: "Второе блюдо",
    note: "Горячие блюда для плотного обеда: курица, говядина, рыба и домашние котлеты.",
    items: [
      {
        title: "Куриное филе в кляре",
        description: "Куриное мясо, обвалянное в тесте.",
        price: 280,
        weight: "160 г",
        image: imageBank.chicken,
      },
      {
        title: "Куриное филе в томатном соусе",
        description: "Куриное мясо в насыщенном томатном соусе.",
        price: 280,
        weight: "160 г",
      },
      {
        title: "Чахохбили из кур",
        description: "Грузинское блюдо из кусочков курицы.",
        price: 250,
        weight: "150 г",
      },
      {
        title: "Шашлык куриный",
        description: "Кусочки куриного мяса, маринованные и жареные на гриле или мангале.",
        price: 280,
        weight: "150 г",
      },
      {
        title: "Вок с курицей",
        description: "Блюдо, приготовленное на сильном огне в воке.",
        price: 250,
        weight: "160 г",
      },
      {
        title: "Плов из говядины",
        description: "Ароматное узбекское блюдо.",
        price: 300,
        weight: "250 г",
        image: imageBank.rice,
      },
      {
        title: "Окорочка жареные",
        description: "Куриные бедрышки, обжаренные до румяной корочки.",
        price: 230,
        weight: "120 г",
      },
      {
        title: "Рыба запеченная",
        description: "Рыба, запеченная в духовке.",
        price: 295,
        weight: "160 г",
      },
      {
        title: "Котлета Нежность",
        description: "Сочная мясная котлета.",
        price: 200,
        weight: "100 г",
      },
      {
        title: "Котлета куриная рубленая",
        description: "Котлета, сделанная из рубленого куриного мяса.",
        price: 160,
        weight: "100 г",
      },
      {
        title: "Котлета домашняя",
        description: "Традиционная котлета из фарша.",
        price: 160,
        weight: "100 г",
      },
      {
        title: "Гуляш из говядины",
        description: "Мясное рагу, приготовленное из кусочков говядины.",
        price: 300,
        weight: "150 г",
      },
      {
        title: "Фрикасе с грибами",
        description: "Нежное мясное блюдо с кусочками мяса и грибами.",
        price: 250,
        weight: "150 г",
      },
      {
        title: "Печень говяжья",
        description: "Жареная или тушеная печень.",
        price: 250,
        weight: "150 г",
      },
      {
        title: "Ленивые голубцы",
        description: "Смесь фарша, риса и капусты в домашнем стиле.",
        price: 250,
        weight: "150 г",
      },
      {
        title: "Манты",
        description: "Азиатские пирожки с мясной начинкой.",
        price: 300,
        weight: "250 г",
      },
      {
        title: "Тефтели",
        description: "Маленькие мясные шарики из фарша и риса.",
        price: 250,
        weight: "130 г",
      },
    ],
  },
  {
    title: "Первое блюдо",
    note: "Наваристые супы и домашняя классика на каждый день.",
    items: [
      {
        title: "Солянка мясная",
        description: "Насыщенный и сытный суп на мясном бульоне.",
        price: 200,
        weight: "250 г",
        image: imageBank.soup,
      },
      {
        title: "Шурпа из баранины",
        description: "Ароматный суп с бараниной.",
        price: 350,
        weight: "250 г",
      },
      {
        title: "Шурпа из говядины",
        description: "Аналог шурпы, но с говядиной.",
        price: 320,
        weight: "250 г",
      },
      {
        title: "Борщ",
        description: "Традиционный свекольный суп.",
        price: 250,
        weight: "250 г",
      },
      {
        title: "Лагман домашний",
        description: "Блюдо узбекской кухни.",
        price: 350,
        weight: "250 г",
      },
      {
        title: "Крем-суп грибной",
        description: "Нежный суп-пюре из грибов.",
        price: 200,
        weight: "250 г",
      },
      {
        title: "Суп рассольник",
        description: "Наваристый суп с рассолом.",
        price: 280,
        weight: "250 г",
      },
      {
        title: "Суп гороховый",
        description: "Густой суп из размягченного гороха.",
        price: 200,
        weight: "250 г",
      },
      {
        title: "Суп рыбный",
        description: "Легкий и ароматный суп на основе рыбного бульона.",
        price: 250,
        weight: "250 г",
      },
      {
        title: "Суп сырный",
        description: "Кремовый суп с добавлением различных сыров.",
        price: 200,
        weight: "250 г",
      },
    ],
  },
  {
    title: "Салаты",
    note: "Холодные салаты к обеду и блюда для самовывоза.",
    items: [
      {
        title: "Салат Оливье",
        description: "Классический русский салат.",
        price: 150,
        weight: "120 г",
        image: imageBank.salad,
      },
      {
        title: "Салат Витаминный",
        description: "Свежий салат из различных овощей.",
        price: 120,
        weight: "120 г",
      },
      {
        title: "Салат Морковный",
        description: "Натертая морковь.",
        price: 120,
        weight: "120 г",
      },
      {
        title: "Салат Крабовый",
        description: "Салат с крабовыми палочками.",
        price: 150,
        weight: "120 г",
      },
      {
        title: "Салат Свекольный",
        description: "Салат из вареной свеклы.",
        price: 120,
        weight: "120 г",
      },
      {
        title: "Салат Винегрет",
        description: "Салат из вареных овощей.",
        price: 120,
        weight: "120 г",
      },
      {
        title: "Салат Мимоза",
        description: "Слоеный салат с горбушой.",
        price: 150,
        weight: "140 г",
      },
      {
        title: "Селедка под шубой",
        description: "Традиционный салат из селедки и овощей.",
        price: 150,
        weight: "140 г",
      },
      {
        title: "Салат овощной Пекин",
        description: "Свежий салат из пекинской капусты.",
        price: 150,
        weight: "120 г",
      },
      {
        title: "Сельдь под шубой",
        description: "Традиционный русский салат.",
        price: 150,
        weight: "100 г",
      },
    ],
  },
  {
    title: "Гарнир",
    note: "Простые гарниры к горячему блюду или комплексному обеду.",
    items: [
      {
        title: "Картошка фри",
        description: "Картофель, нарезанный соломкой и жареный во фритюре.",
        price: 180,
        weight: "150 г",
      },
      {
        title: "Рис",
        description: "Универсальный гарнир.",
        price: 80,
        weight: "150 г",
        image: imageBank.rice,
      },
      {
        title: "Гречка",
        description: "Питательный и полезный гарнир из гречневой крупы.",
        price: 80,
        weight: "150 г",
      },
      {
        title: "Макароны",
        description: "Паста.",
        price: 80,
        weight: "150 г",
      },
      {
        title: "Картошка запеченная",
        description: "Картофель, запеченный в раскаленной духовке.",
        price: 120,
        weight: "150 г",
      },
      {
        title: "Картошка отварная",
        description: "Простое блюдо из отварного картофеля.",
        price: 120,
        weight: "150 г",
      },
      {
        title: "Картофельное пюре",
        description: "Нежное пюре из отварного картофеля.",
        price: 120,
        weight: "150 г",
      },
    ],
  },
  {
    title: "Выпечка",
    note: "Свежая выпечка из печи: удобно взять с собой или добавить к супу.",
    items: [
      {
        title: "Пирожок с зеленым луком и яйцом",
        description: "Пирожок с начинкой из отварных яиц и зеленого лука.",
        price: 70,
        weight: "80 г",
        image: imageBank.bakery,
      },
      {
        title: "Самса с говяжьим мясом",
        description:
          "Пирожки с начинкой из мясного фарша, запеченные в тесте, популярны в среднеазиатской кухне.",
        price: 90,
        weight: "100 г",
      },
      {
        title: "Лепешка",
        description: "Круглое хлебное изделие, выпекается в печи или тандыре.",
        price: 40,
        weight: "250 г",
      },
    ],
  },
  {
    title: "Завтрак",
    note: "Утренние блюда, которые быстро собираются на самовывоз.",
    items: [
      {
        title: "Сырники",
        description: "Маленькие круглые лепешки из творога.",
        price: 80,
        weight: "80 г",
        image: imageBank.breakfast,
      },
      {
        title: "Яичница с сосиской",
        description: "Простое и сытное блюдо.",
        price: 250,
        weight: "140 г",
      },
      {
        title: "Каша овсяная",
        description: "Горячее блюдо из овсяных хлопьев.",
        price: 150,
        weight: "150 г",
      },
    ],
  },
  {
    title: "Комплексный обед",
    note: "Сбалансированный обед: первое блюдо, гарнир, горячее и салат.",
    items: [
      {
        title: "Комплексный обед №2",
        description:
          "Сытный обед: первое блюдо, горячее с гарниром, салат, хлеб и напиток.",
        price: 400,
        weight: "750 г",
        image: imageBank.lunch2,
      },
      {
        title: "Комплексный обед №1",
        description:
          "Большой домашний обед: суп, горячее блюдо, гарнир, салат, хлеб и напиток.",
        price: 450,
        weight: "800 г",
        image: imageBank.lunch1,
      },
    ],
  },
  {
    title: "Напитки",
    note: "Домашние напитки к обеду.",
    items: [
      {
        title: "Чай каркаде",
        description: "Напиток на основе сушеных цветков гибискуса.",
        price: 50,
        weight: "200 г",
      },
      {
        title: "Компот из сухофруктов",
        description:
          "Сладкий напиток из отваренных сухофруктов: яблоки, груши, изюм и специи.",
        price: 45,
        weight: "200 г",
      },
    ],
  },
];

const reviews = [
  {
    name: "Мария",
    text: "Наконец-то место, где доставка выглядит так же аккуратно, как в зале. Еда приезжает теплой, красиво собранной и очень вкусной.",
  },
  {
    name: "Илья",
    text: "Беру завтраки перед работой. Нравится, что меню понятное, цены честные, а вкус всегда стабильный.",
  },
  {
    name: "Анна",
    text: "Заказывали комплексные обеды в офис. Все быстро подтвердили, упаковали без суеты, коллеги просили контакты.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0 },
};

const categories = ["Все", ...menuSections.map((section) => section.title)];
const itemIndex = menuSections.flatMap((section) => section.items.map((item) => item));

function LogoMark() {
  return (
    <span className="relative inline-flex h-10 w-10 items-center justify-center rounded-full bg-[#f6c85f] text-[#1c1712] shadow-[0_0_30px_rgba(246,200,95,0.35)]">
      <svg viewBox="0 0 32 32" className="h-6 w-6" aria-hidden="true">
        <path
          d="M6 17.5c0-5.6 4.3-10 10-10s10 4.4 10 10v1H6v-1Z"
          fill="currentColor"
        />
        <path d="M7 21h18" stroke="#f6c85f" strokeLinecap="round" strokeWidth="2.4" />
        <path
          d="M12 12.4c1.7-1.1 4.1-1.4 6.6-.3"
          stroke="#f6c85f"
          strokeLinecap="round"
          strokeWidth="2"
        />
      </svg>
    </span>
  );
}

function formatPrice(price: number) {
  return `${price.toLocaleString("ru-RU")} ₽`;
}

export default function App() {
  const { scrollY } = useScroll();
  const heroScale = useTransform(scrollY, [0, 700], [1, 1.12]);
  const heroY = useTransform(scrollY, [0, 700], [0, 90]);
  const [activeCategory, setActiveCategory] = useState("Все");
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<Record<string, number>>({});

  const filteredSections = useMemo(() => {
    const query = search.trim().toLowerCase();

    return menuSections
      .filter((section) => activeCategory === "Все" || section.title === activeCategory)
      .map((section) => ({
        ...section,
        items: section.items.filter((item) => {
          const haystack = `${item.title} ${item.description}`.toLowerCase();
          return !query || haystack.includes(query);
        }),
      }))
      .filter((section) => section.items.length > 0);
  }, [activeCategory, search]);

  const cartItems = useMemo(
    () =>
      Object.entries(cart)
        .map(([title, quantity]) => {
          const item = itemIndex.find((menuItem) => menuItem.title === title);
          return item ? { ...item, quantity } : null;
        })
        .filter(Boolean) as Array<MenuItem & { quantity: number }>,
    [cart]
  );

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const changeQuantity = (title: string, delta: number) => {
    setCart((current) => {
      const nextQuantity = Math.max(0, (current[title] ?? 0) + delta);
      if (nextQuantity === 0) {
        const nextCart = { ...current };
        delete nextCart[title];
        return nextCart;
      }
      return { ...current, [title]: nextQuantity };
    });
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#17130f] text-[#fff8ea] selection:bg-[#f6c85f] selection:text-[#17130f]">
      <nav className="fixed left-0 top-0 z-50 w-full border-b border-white/10 bg-[#17130f]/55 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 md:px-8">
          <a href="#top" className="flex items-center gap-3" aria-label="Щедро и вкусно">
            <LogoMark />
            <span className="font-serif text-xl font-semibold tracking-tight">Щедро и вкусно</span>
          </a>
          <div className="hidden items-center gap-8 text-sm text-[#fff2d2]/75 md:flex">
            <a className="transition hover:text-[#f6c85f]" href="#menu">
              Меню
            </a>
            <a className="transition hover:text-[#f6c85f]" href="#lunch">
              Обеды
            </a>
            <a className="transition hover:text-[#f6c85f]" href="#reviews">
              Отзывы
            </a>
            <a className="transition hover:text-[#f6c85f]" href="#contacts">
              Адрес
            </a>
          </div>
          <a
            href="tel:+79990000000"
            className="rounded-full bg-[#fff8ea] px-5 py-2 text-sm font-semibold text-[#17130f] transition hover:bg-[#f6c85f]"
          >
            Заказать
          </a>
        </div>
      </nav>

      <section id="top" className="relative min-h-screen overflow-hidden">
        <motion.img
          src={heroImage}
          alt="Накрытый стол с завтраком, кофе и свежими продуктами"
          className="absolute inset-0 h-full w-full object-cover"
          style={{ scale: heroScale, y: heroY }}
        />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,rgba(23,19,15,0.94)_0%,rgba(23,19,15,0.76)_38%,rgba(23,19,15,0.24)_100%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_25%_45%,rgba(246,200,95,0.22),transparent_32%)]" />

        <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl items-center px-5 pb-16 pt-28 md:px-8">
          <motion.div
            className="max-w-3xl"
            animate="visible"
            initial="hidden"
            transition={{ duration: 0.8, ease: "easeOut" }}
            variants={fadeUp}
          >
            <motion.div
              className="mb-8 flex items-center gap-4"
              animate={{ opacity: 1, x: 0 }}
              initial={{ opacity: 0, x: -18 }}
              transition={{ duration: 0.7, delay: 0.15 }}
            >
              <LogoMark />
              <span className="font-serif text-3xl font-semibold tracking-tight text-[#f6c85f] md:text-5xl">
                Щедро и вкусно
              </span>
            </motion.div>

            <h1 className="max-w-3xl font-serif text-5xl font-semibold leading-[0.94] tracking-[-0.05em] text-[#fff8ea] md:text-8xl">
              Домашняя еда на МКАД, 23-й километр.
            </h1>
            <p className="mt-7 max-w-xl text-lg leading-8 text-[#fff2d2]/78 md:text-xl">
              Первые блюда, горячее, салаты, гарниры, выпечка и комплексные обеды. Готовим щедро, упаковываем аккуратно, отдаем быстро.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <a
                href="#menu"
                className="rounded-full bg-[#f6c85f] px-7 py-4 text-center text-sm font-bold uppercase tracking-[0.18em] text-[#17130f] transition hover:bg-[#ffe29a]"
              >
                Смотреть меню
              </a>
              <a
                href="tel:+79990000000"
                className="rounded-full border border-[#fff8ea]/35 px-7 py-4 text-center text-sm font-bold uppercase tracking-[0.18em] text-[#fff8ea] transition hover:border-[#f6c85f] hover:text-[#f6c85f]"
              >
                Позвонить
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="menu" className="relative bg-[#fff8ea] px-5 py-24 text-[#1d1812] md:px-8 md:py-32">
        <div className="mx-auto max-w-7xl">
          <motion.div
            className="flex flex-col justify-between gap-8 md:flex-row md:items-end"
            initial="hidden"
            transition={{ duration: 0.65 }}
            variants={fadeUp}
            viewport={{ once: true, amount: 0.35 }}
            whileInView="visible"
          >
            <div>
              <p className="text-sm font-bold uppercase tracking-[0.28em] text-[#b8652b]">Меню</p>
              <h2 className="mt-4 max-w-2xl font-serif text-4xl font-semibold tracking-[-0.04em] md:text-6xl">
                Полный каталог блюд
              </h2>
            </div>
            <p className="max-w-md text-base leading-7 text-[#5b4a3c]">
              Выберите категорию, найдите блюдо по названию и соберите предварительный заказ. Итог можно подтвердить по телефону.
            </p>
          </motion.div>

          <div className="mt-12 grid gap-8 lg:grid-cols-[1fr_360px]">
            <div>
              <div className="sticky top-[73px] z-20 -mx-5 border-y border-[#1d1812]/10 bg-[#fff8ea]/92 px-5 py-4 backdrop-blur-xl md:top-[81px] md:mx-0 md:rounded-[2rem] md:border md:px-5">
                <label className="sr-only" htmlFor="menu-search">
                  Найти блюдо
                </label>
                <input
                  id="menu-search"
                  className="w-full rounded-full border border-[#1d1812]/15 bg-white px-5 py-4 text-sm outline-none transition placeholder:text-[#7d6a59] focus:border-[#b8652b]"
                  placeholder="Найти борщ, плов, сырники..."
                  type="search"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                />
                <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
                  {categories.map((category) => (
                    <button
                      key={category}
                      className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition ${
                        activeCategory === category
                          ? "bg-[#1d1812] text-[#fff8ea]"
                          : "bg-[#f1e5cf] text-[#5b4a3c] hover:bg-[#ead8b7]"
                      }`}
                      onClick={() => setActiveCategory(category)}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-10 space-y-16">
                {filteredSections.length === 0 ? (
                  <div className="border-y border-[#1d1812]/15 py-12 text-center text-[#5b4a3c]">
                    Ничего не найдено. Попробуйте другой запрос.
                  </div>
                ) : (
                  filteredSections.map((section) => (
                    <motion.div
                      key={section.title}
                      initial="hidden"
                      transition={{ duration: 0.55 }}
                      variants={fadeUp}
                      viewport={{ once: true, amount: 0.18 }}
                      whileInView="visible"
                    >
                      <div className="mb-6 flex flex-col justify-between gap-3 border-b border-[#1d1812]/15 pb-5 md:flex-row md:items-end">
                        <div>
                          <h3 className="font-serif text-3xl font-semibold tracking-[-0.03em] md:text-4xl">
                            {section.title}
                          </h3>
                          <p className="mt-2 max-w-2xl text-sm leading-6 text-[#6b5948]">{section.note}</p>
                        </div>
                        <span className="text-sm font-semibold text-[#b8652b]">{section.items.length} поз.</span>
                      </div>

                      <div className="divide-y divide-[#1d1812]/10">
                        {section.items.map((item, index) => {
                          const quantity = cart[item.title] ?? 0;

                          return (
                            <motion.article
                              key={item.title}
                              className="group grid gap-5 py-5 sm:grid-cols-[96px_1fr] lg:grid-cols-[96px_1fr_150px]"
                              initial={{ opacity: 0, y: 18 }}
                              transition={{ duration: 0.42, delay: Math.min(index * 0.025, 0.18) }}
                              viewport={{ once: true, amount: 0.25 }}
                              whileHover={{ x: 4 }}
                              whileInView={{ opacity: 1, y: 0 }}
                            >
                              <div className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-[1.4rem] bg-[#ead8b7] font-serif text-2xl font-semibold text-[#b8652b]">
                                {item.image ? (
                                  <img src={item.image} alt={item.title} className="h-full w-full object-cover" />
                                ) : (
                                  item.title.slice(0, 1)
                                )}
                              </div>

                              <div>
                                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                                  <h4 className="font-serif text-2xl font-semibold tracking-[-0.02em]">
                                    {item.title}
                                  </h4>
                                  {item.weight && <span className="text-sm text-[#7d6a59]">{item.weight}</span>}
                                </div>
                                <p className="mt-2 max-w-2xl text-sm leading-6 text-[#5b4a3c]">{item.description}</p>
                              </div>

                              <div className="flex items-center justify-between gap-4 lg:flex-col lg:items-end lg:justify-center">
                                <div className="text-2xl font-bold tracking-tight">{formatPrice(item.price)}</div>
                                {quantity > 0 ? (
                                  <div className="inline-flex items-center rounded-full bg-[#1d1812] p-1 text-[#fff8ea]">
                                    <button
                                      className="h-9 w-9 rounded-full text-lg transition hover:bg-white/12"
                                      onClick={() => changeQuantity(item.title, -1)}
                                      aria-label={`Убрать ${item.title}`}
                                    >
                                      -
                                    </button>
                                    <span className="min-w-8 text-center text-sm font-bold">{quantity}</span>
                                    <button
                                      className="h-9 w-9 rounded-full text-lg transition hover:bg-white/12"
                                      onClick={() => changeQuantity(item.title, 1)}
                                      aria-label={`Добавить ${item.title}`}
                                    >
                                      +
                                    </button>
                                  </div>
                                ) : (
                                  <button
                                    className="rounded-full bg-[#1d1812] px-5 py-3 text-sm font-semibold text-[#fff8ea] transition hover:bg-[#b8652b]"
                                    onClick={() => changeQuantity(item.title, 1)}
                                  >
                                    Добавить
                                  </button>
                                )}
                              </div>
                            </motion.article>
                          );
                        })}
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </div>

            <motion.aside
              className="h-fit rounded-[2rem] bg-[#1d1812] p-6 text-[#fff8ea] shadow-2xl shadow-black/20 lg:sticky lg:top-28"
              animate={{ opacity: 1, y: 0 }}
              initial={{ opacity: 0, y: 24 }}
              transition={{ duration: 0.6, delay: 0.15 }}
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="text-sm font-bold uppercase tracking-[0.22em] text-[#f6c85f]">Заказ</p>
                  <h3 className="mt-2 font-serif text-3xl font-semibold">Корзина</h3>
                </div>
                <span className="rounded-full bg-[#f6c85f] px-3 py-1 text-sm font-bold text-[#1d1812]">
                  {cartCount}
                </span>
              </div>

              {cartItems.length === 0 ? (
                <p className="mt-8 text-sm leading-6 text-[#fff2d2]/65">
                  Добавьте блюда из меню, чтобы увидеть примерную сумму заказа.
                </p>
              ) : (
                <div className="mt-6 divide-y divide-white/10">
                  {cartItems.map((item) => (
                    <div key={item.title} className="flex items-start justify-between gap-4 py-4">
                      <div>
                        <p className="font-semibold">{item.title}</p>
                        <p className="mt-1 text-sm text-[#fff2d2]/55">{item.quantity} x {formatPrice(item.price)}</p>
                      </div>
                      <p className="font-bold">{formatPrice(item.quantity * item.price)}</p>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-8 border-t border-white/12 pt-6">
                <div className="flex items-center justify-between text-lg">
                  <span className="text-[#fff2d2]/65">Итого</span>
                  <motion.span
                    key={total}
                    className="font-serif text-4xl font-semibold text-[#f6c85f]"
                    animate={{ scale: 1 }}
                    initial={{ scale: 0.9 }}
                    transition={{ duration: 0.18 }}
                  >
                    {formatPrice(total)}
                  </motion.span>
                </div>
                <a
                  className="mt-6 flex w-full justify-center rounded-full bg-[#f6c85f] px-6 py-4 text-sm font-bold uppercase tracking-[0.16em] text-[#17130f] transition hover:bg-[#ffe29a]"
                  href="tel:+79990000000"
                >
                  Подтвердить по телефону
                </a>
                <p className="mt-4 text-center text-xs leading-5 text-[#fff2d2]/45">
                  Цены и наличие блюд лучше уточнить при звонке.
                </p>
              </div>
            </motion.aside>
          </div>
        </div>
      </section>

      <section id="lunch" className="relative overflow-hidden py-24 md:py-32">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_35%,rgba(246,200,95,0.18),transparent_34%)]" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-5 md:grid-cols-[0.8fr_1fr] md:items-center md:px-8">
          <motion.div
            className="max-w-2xl"
            initial="hidden"
            transition={{ duration: 0.65 }}
            variants={fadeUp}
            viewport={{ once: true, amount: 0.4 }}
            whileInView="visible"
          >
            <p className="text-sm font-bold uppercase tracking-[0.28em] text-[#f6c85f]">Комплексные обеды</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold tracking-[-0.04em] text-[#fff8ea] md:text-6xl">
              Полный обед от 400 ₽
            </h2>
            <p className="mt-6 text-lg leading-8 text-[#fff2d2]/72">
              Первое блюдо, горячее, гарнир, салат, хлеб и напиток. Подходит для офиса, дороги и быстрого домашнего обеда.
            </p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <a
                href="#menu"
                className="rounded-full bg-[#fff8ea] px-7 py-4 text-center text-sm font-bold uppercase tracking-[0.18em] text-[#17130f] transition hover:bg-[#f6c85f]"
                onClick={() => setActiveCategory("Комплексный обед")}
              >
                Выбрать обед
              </a>
              <a
                href="tel:+79990000000"
                className="rounded-full border border-[#fff8ea]/35 px-7 py-4 text-center text-sm font-bold uppercase tracking-[0.18em] text-[#fff8ea] transition hover:border-[#f6c85f] hover:text-[#f6c85f]"
              >
                Уточнить наличие
              </a>
            </div>
          </motion.div>

          <div className="grid gap-5 md:grid-cols-2">
            <motion.figure
              className="md:translate-y-10"
              initial={{ opacity: 0, y: 32 }}
              transition={{ duration: 0.65, delay: 0.1 }}
              viewport={{ once: true, amount: 0.3 }}
              whileInView={{ opacity: 1, y: 0 }}
            >
              <img
                src={imageBank.lunch2}
                alt="Комплексный обед №2: суп, салат, хлеб, напиток и горячее"
                className="aspect-[4/5] w-full rounded-[2rem] object-cover shadow-2xl shadow-black/30"
              />
              <figcaption className="mt-4 flex items-center justify-between gap-4 text-sm text-[#fff2d2]/70">
                <span className="font-serif text-2xl font-semibold text-[#f6c85f]">Комплексный обед №2</span>
                <span>400 ₽</span>
              </figcaption>
            </motion.figure>
            <motion.figure
              initial={{ opacity: 0, y: -32 }}
              transition={{ duration: 0.65, delay: 0.18 }}
              viewport={{ once: true, amount: 0.3 }}
              whileInView={{ opacity: 1, y: 0 }}
            >
              <img
                src={imageBank.lunch1}
                alt="Комплексный обед №1: суп, салат, хлеб, напиток и горячее с гречкой"
                className="aspect-[4/5] w-full rounded-[2rem] object-cover shadow-2xl shadow-black/30"
              />
              <figcaption className="mt-4 flex items-center justify-between gap-4 text-sm text-[#fff2d2]/70">
                <span className="font-serif text-2xl font-semibold text-[#f6c85f]">Комплексный обед №1</span>
                <span>450 ₽</span>
              </figcaption>
            </motion.figure>
          </div>
        </div>
      </section>

      <section id="reviews" className="px-5 py-24 md:px-8 md:py-32">
        <div className="mx-auto max-w-7xl">
          <motion.div
            className="max-w-3xl"
            initial="hidden"
            transition={{ duration: 0.65 }}
            variants={fadeUp}
            viewport={{ once: true, amount: 0.35 }}
            whileInView="visible"
          >
            <p className="text-sm font-bold uppercase tracking-[0.28em] text-[#f6c85f]">Отзывы</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold tracking-[-0.04em] text-[#fff8ea] md:text-6xl">
              Нас советуют друзьям
            </h2>
          </motion.div>

          <div className="mt-14 divide-y divide-[#fff8ea]/12 border-y border-[#fff8ea]/12">
            {reviews.map((review, index) => (
              <motion.figure
                key={review.name}
                className="grid gap-5 py-8 md:grid-cols-[220px_1fr] md:py-10"
                initial={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.55, delay: index * 0.08 }}
                viewport={{ once: true, amount: 0.45 }}
                whileInView={{ opacity: 1, x: 0 }}
              >
                <figcaption>
                  <div className="font-serif text-2xl font-semibold text-[#f6c85f]">{review.name}</div>
                  <div className="mt-2 text-sm uppercase tracking-[0.2em] text-[#fff2d2]/45">5.0 из 5</div>
                </figcaption>
                <blockquote className="max-w-4xl text-xl leading-9 text-[#fff2d2]/82 md:text-2xl md:leading-10">
                  "{review.text}"
                </blockquote>
              </motion.figure>
            ))}
          </div>
        </div>
      </section>

      <section id="contacts" className="bg-[#fff8ea] px-5 py-20 text-[#1d1812] md:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 md:grid-cols-[1fr_1.2fr] md:items-end">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.28em] text-[#b8652b]">Контакты</p>
            <h2 className="mt-4 font-serif text-4xl font-semibold tracking-[-0.04em] md:text-6xl">
              Заберите заказ по пути
            </h2>
          </div>
          <div className="space-y-5 text-lg leading-8 text-[#5b4a3c]">
            <p>Москва, МКАД, 23-й километр, внешняя сторона, вл3.</p>
            <p>Ежедневно с 8:00 до 22:00. Самовывоз и предварительный заказ по телефону.</p>
          </div>
        </div>
      </section>

      <footer className="border-t border-[#fff8ea]/12 px-5 py-10 md:px-8">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 text-sm text-[#fff2d2]/60 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3 text-[#fff8ea]">
            <LogoMark />
            <span className="font-serif text-xl font-semibold">Щедро и вкусно</span>
          </div>
          <p>Москва, МКАД, 23-й километр, внешняя сторона, вл3.</p>
          <a className="text-[#f6c85f] transition hover:text-[#ffe29a]" href="tel:+79990000000">
            +7 999 000-00-00
          </a>
        </div>
      </footer>
    </main>
  );
}